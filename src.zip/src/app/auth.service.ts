
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private isLoggedIn = false;

  login(username: string, password: string): Observable<boolean> {
    // Simulate an API call for demo purposes
    if (username === 'user' && password === 'password') {
      this.isLoggedIn = true;
      return of(true); // Successful login
    } else {
      this.isLoggedIn = false;
      return of(false); // Invalid credentials
    }
  }

  logout(): void {
    this.isLoggedIn = false;
  }

  isAuthenticated(): boolean {
    return this.isLoggedIn;
  }
}
