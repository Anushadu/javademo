import { Component } from '@angular/core';

@Component({
  selector: 'app-expenses',
  templateUrl: './expenses.component.html',
  styleUrls: ['./expenses.component.css']
})
export class ExpensesComponent {
  expenses: Expense[] = [
    { id: 1, description: 'Groceries', amount: 50.25 },
    { id: 2, description: 'Dinner', amount: 75.00 },
    { id: 3, description: 'Movie tickets', amount: 30.00 }
    // Add more expenses as needed
  ];

  constructor() {}

  // Add methods for expense management here
}

interface Expense {
  id: number;
  description: string;
  amount: number;
}
